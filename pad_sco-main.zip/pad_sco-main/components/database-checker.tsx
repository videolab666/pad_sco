"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Loader2, Database, AlertCircle, CheckCircle } from "lucide-react"
import { checkTablesExist, checkTablesContent } from "@/lib/supabase"
import { logEvent } from "@/lib/error-logger"
import { tSync } from "@/lib/log-i18n"
import { useLanguage } from "@/contexts/language-context"

export function DatabaseChecker() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [tablesStatus, setTablesStatus] = useState<any>(null)
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [tablesContent, setTablesContent] = useState<any>(null)
  const [isChecking, setIsChecking] = useState(true)
  const { t } = useLanguage()

  const checkDatabase = async () => {
    setIsChecking(true)
    try {
      const status = await checkTablesExist()
      setTablesStatus(status)
      logEvent("info", tSync("logMessages.checkingTablesExist"), "DatabaseChecker", status)

      if (status.exists) {
        const content = await checkTablesContent()
        setTablesContent(content)
        logEvent("info", tSync("logMessages.checkingTablesContent"), "DatabaseChecker", content)
      }
    } catch (error: any) {
      logEvent("error", tSync("logMessages.errorCheckTables"), "DatabaseChecker", error)
    } finally {
      setIsChecking(false)
    }
  }

  useEffect(() => {
    checkDatabase()
  }, [])

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          {t("debugPage.checkDatabase")}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {isChecking ? (
          <div className="flex items-center justify-center p-4">
            <Loader2 className="h-6 w-6 animate-spin mr-2" />
            <span>{t("debugPage.checkingDatabase")}</span>
          </div>
        ) : tablesStatus ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="border rounded-md p-3">
                <h3 className="font-medium mb-2">{t("debugPage.matchesTable")}</h3>
                {tablesStatus.matchesExists ? (
                  <div className="flex items-center text-green-600">
                    <CheckCircle className="h-5 w-5 mr-2" />
                    {t("debugPage.tableExists")}
                  </div>
                ) : (
                  <div className="flex items-center text-amber-600">
                    <AlertCircle className="h-5 w-5 mr-2" />
                    {t("debugPage.tableNotExists")}
                    {tablesStatus.errors?.matches && (
                      <span className="text-xs ml-2 text-red-500">{tablesStatus.errors.matches}</span>
                    )}
                  </div>
                )}
              </div>

              <div className="border rounded-md p-3">
                <h3 className="font-medium mb-2">{t("debugPage.playersTable")}</h3>
                {tablesStatus.playersExists ? (
                  <div className="flex items-center text-green-600">
                    <CheckCircle className="h-5 w-5 mr-2" />
                    {t("debugPage.tableExists")}
                  </div>
                ) : (
                  <div className="flex items-center text-amber-600">
                    <AlertCircle className="h-5 w-5 mr-2" />
                    {t("debugPage.tableNotExists")}
                    {tablesStatus.errors?.players && (
                      <span className="text-xs ml-2 text-red-500">{tablesStatus.errors.players}</span>
                    )}
                  </div>
                )}
              </div>
            </div>

            {tablesStatus.exists && tablesContent && (
              <div className="space-y-4">
                <h3 className="font-medium">{t("debugPage.tablesContent")}</h3>

                <div className="border rounded-md p-3">
                  <h4 className="font-medium mb-2">{t("debugPage.playersLabel")} ({tablesContent.players.length})</h4>
                  {tablesContent.players.length > 0 ? (
                    <div className="bg-gray-100 p-2 rounded-md overflow-auto max-h-40">
                      <pre className="text-xs">{JSON.stringify(tablesContent.players, null, 2)}</pre>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">{t("debugPage.playersEmpty")}</p>
                  )}
                </div>

                <div className="border rounded-md p-3">
                  <h4 className="font-medium mb-2">{t("debugPage.matchesLabel")} ({tablesContent.matches.length})</h4>
                  {tablesContent.matches.length > 0 ? (
                    <div className="bg-gray-100 p-2 rounded-md overflow-auto max-h-40">
                      <pre className="text-xs">{JSON.stringify(tablesContent.matches, null, 2)}</pre>
                    </div>
                  ) : (
                    <p className="text-sm text-muted-foreground">{t("debugPage.matchesEmpty")}</p>
                  )}
                </div>
              </div>
            )}

            {!tablesStatus.exists && (
              <Alert className="bg-amber-50 border-amber-200">
                <AlertCircle className="h-4 w-4 text-amber-800" />
                <AlertTitle className="text-amber-800">{t("debugPage.tablesNotCreated")}</AlertTitle>
                <AlertDescription className="text-amber-800">
                  {t("debugPage.tablesNotCreatedDesc")}
                </AlertDescription>
              </Alert>
            )}
          </div>
        ) : (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>{t("debugPage.errorTitle")}</AlertTitle>
            <AlertDescription>{t("debugPage.checkTablesError")}</AlertDescription>
          </Alert>
        )}
      </CardContent>
      <CardFooter>
        <Button variant="outline" size="sm" onClick={checkDatabase} disabled={isChecking}>
          {isChecking ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          {t("debugPage.checkDatabase")}
        </Button>
      </CardFooter>
    </Card>
  )
}
